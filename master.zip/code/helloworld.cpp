#include <cstdlib>
#include <iostream>

int main(int argc, char *argv[]) {
  // print Hello World to the stdout
  std::cout << "Hello World!" << std::endl;
  return EXIT_SUCCESS;
}
